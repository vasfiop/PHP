<?php
namespace Common\Model;
use Base\BaseModel;

final class UserModel extends BaseModel{
    
    //操作的数据表名
    protected $table = "user";

}