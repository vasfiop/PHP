<?php 
/* 数据库配置文件 */
define('HOST', '127.0.0.1');
define('USERNAME', 'root');
define('PASSWORD','');
define('DB','booksystem');
define('DB_CHARSET', 'utf8');
