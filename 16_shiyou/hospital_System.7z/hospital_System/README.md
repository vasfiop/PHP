# bookSystem

1.本项目是医院预约挂号系统，主要实现预约挂号，后台管理等。

2.后端语言使用PHP。

3.数据库使用MySQL。

4.使用wamp软件的集成环境进行开发。

5.用户登录页面http://localhost/booksystem/index.php

6.后台登录页面http://localhost/booksystem/admin/login.php

7.相关截图请查看screenshot文件夹
