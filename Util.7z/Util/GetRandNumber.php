<?php

namespace Get_Rand;

function Get_Rand($first, $end)
{
    return rand($first, $end);
}
